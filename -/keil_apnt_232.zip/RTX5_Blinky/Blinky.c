#include "MKL26Z4.h"                    // Device header
#include "RTE_Components.h"             // Component selection
#include "cmsis_os2.h"                  // ::CMSIS:RTOS2
#include "EventRecorder.h"

unsigned int counter = 0;
unsigned int counter2 = 0;

/*----------------------------------------------------------------------------
 *  job1 thread
 *---------------------------------------------------------------------------*/
void job1 (void  *argument) {

	for (;;) {
   counter++;
	 if (counter > 0x0F) counter = 0;
		osDelay(200);
     }
   }

/*----------------------------------------------------------------------------
 *  job2 thread
 *---------------------------------------------------------------------------*/
void job2 (void *argument) {

  for (;;) {
	counter2++;
	if (counter2 > 0x0F) counter2 = 0;
	osDelay(200);
	}
}

/*---------------------------------------------
  MAIN function
 *---------------------------------------------*/
int main (void) {
	SystemCoreClockUpdate();
	EventRecorderInitialize(EventRecordAll, 1); 

	osKernelInitialize (); // setup kernel
	
	osThreadNew (job1, NULL, NULL); 
	osThreadNew (job2, NULL, NULL);
	
	osKernelStart();
	
}

