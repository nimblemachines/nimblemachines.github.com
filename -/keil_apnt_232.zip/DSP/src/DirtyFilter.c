/*----------------------------------------------------------------------------
 * Name:    DirtyFilter.c
 * Purpose: Freescale MKL25Z128xxx4 / Freedom Board
 *----------------------------------------------------------------------------
 *
 *   IIR Oscillator and filter example
 *
 *   This example program generates a sinusoidal signal, disturbed by 
 *   another sine signal of higher frequency.
 *   An IIR low pass filter is then used to filter the disturbed signal
 *   to reconstruct the original sine wave.
 *
 *   This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2012 Keil - An ARM Company.
 *----------------------------------------------------------------------------*/

#include "MKL25Z4.h"                    // Device header
#include "cmsis_os.h"                   // ARM::CMSIS:RTOS:Keil RTX
#include "arm_math.h"
#include "sine_generator.h"
#include "rtxtime.h"
#include "low_pass_filter.h"

osThreadId tid_sine_gen;
osThreadId tid_noise_gen;
osThreadId tid_disturb_gen;
osThreadId tid_filter_tsk;
osThreadId tid_sync_tsk;
osThreadId tid_clock;

//-------- <<< Use Configuration Wizard in Context Menu >>> -----------------
//
// <e>Oscillator Configuration
// <i>This is a demonstration on how to use the Configuration Wizard to create an easy configuration menu.

#define ENABLE_CONFIG 1
// =============================
//   <o>Oscillator Sampling Frequency [Hz] <1000-10000>
//   <i> Set the oscillator sampling frequency.
//   <i> Default: 5000  (5 KHz)
#define SAMPLING_FREQ 10000  // generating task (5 KHz)

//   <o>Noise Frequency [Hz] <500-10000>
//   <i> Set the noise signal frequency.
//   <i> Default: 1500 Hz
#define NOISE_FREQ    500  // noise (2 KHz)

//   <o>Signal Frequency [Hz] <100-1000>
//   <i> Set the signal frequency.
//   <i> Default: 330 Hz
#define SIGNAL_FREQ    100  // disturbed signal (250 Hz)

// </e>
//------------- <<< end of configuration section >>> -----------------------

void SystemInit (void);

sine_generator_q15_t Signal_set;
sine_generator_q15_t Noise_set;

q15_t sine;
q15_t noise;
q15_t disturbed;
q15_t filtered;

/*----------------------------------------------------------------------------
 *      Function 'signal_func' called from multiple threads
 *---------------------------------------------------------------------------*/
void signal_func (osThreadId tid)  {
  osSignalSet(tid_clock, 0x0100);           /* set signal to clock thread    */
  osDelay(50);                              /* delay 50ms                     */
  osSignalSet(tid_clock, 0x0100);           /* set signal to clock thread    */
  osDelay(50);                              /* delay 50ms                     */
  osSignalSet(tid, 0x0001);                 /* set signal to thread 'thread' */
  osDelay(50);                              /* delay 50ms                     */
}
/*
*********************************************************************
*
* Sine Generator thread
*
*********************************************************************
*/

void sine_gen(void  const *argument)
{
  while(1)
  {
		osSignalWait (0x0001, 0xFFFF);
    sine = sine_calc_sample_q15(&Signal_set) / 2;
		signal_func(tid_noise_gen);
  }
}

/*
*********************************************************************
*
* Noise Sine Generator thread
*
*********************************************************************
*/

void noise_gen(void  const *argument)
{
  while(1)
  {
		osSignalWait(0x0001, 0xFFFF);
    noise = sine_calc_sample_q15(&Noise_set) / 6;
		signal_func(tid_disturb_gen);
  }
}

/*
*********************************************************************
*
* 1st Disturb Generator thread
*
* Adds Noise to Signal
*
*********************************************************************
*/

void disturb_gen(void const *argument)
{
  while(1)
  {
		osSignalWait(0x0001, 0xFFFF);
    disturbed = sine + noise;
		signal_func(tid_filter_tsk);
  }
}

/*
*********************************************************************
*
* Filter thread
*
* Extract Signal from disturbed signal by filtering out Noise
*
*********************************************************************
*/

void filter_tsk(void const *argument)
{
  while(1)
  {
		osSignalWait(0x0001, 0xFFFF);
    filtered = low_pass_filter(&disturbed); 
		signal_func(tid_sync_tsk);
  }
}

/*
*********************************************************************
*
* Synchronization thread
*
* Periodically starts the signal generation process
*
*********************************************************************
*/

void sync_tsk(void  const *argument)
{
  while(1)
  {
		osDelay(2);
		osSignalWait(0x0001, osWaitForever);
		signal_func(tid_sine_gen);
  }
}

/*
*********************************************************************
*
* Initialization function
*
*********************************************************************
*/
osThreadDef(sine_gen, osPriorityNormal, 1, 0);
osThreadDef(noise_gen, osPriorityNormal, 1, 0);
osThreadDef(disturb_gen, osPriorityNormal, 1, 0);
osThreadDef(filter_tsk, osPriorityNormal, 1, 0);
osThreadDef(sync_tsk, osPriorityNormal, 1, 0);

int main(void)
{
  SystemCoreClockUpdate();
	
	// compute coefficients for IIR sine generators
	sine_generator_init_q15(&Noise_set, NOISE_FREQ, SAMPLING_FREQ);
  sine_generator_init_q15(&Signal_set, SIGNAL_FREQ, SAMPLING_FREQ);
  
	// initialize low pass filter
  low_pass_filter_init();
	
	tid_sine_gen = osThreadCreate(osThread(sine_gen), NULL);
  tid_noise_gen = osThreadCreate(osThread(noise_gen), NULL);
  tid_disturb_gen = osThreadCreate(osThread(disturb_gen), NULL);
  tid_filter_tsk = osThreadCreate(osThread(filter_tsk), NULL);
  tid_sync_tsk = osThreadCreate(osThread(sync_tsk), NULL); 
	
	osSignalSet(tid_sine_gen, 0x0001);
	osDelay(osWaitForever);
	while(1);
}


