/*----------------------------------------------------------------------------
 * Name:    rtxtime.h
 * Purpose: Freescale MKL25Z128xxx4 / Freedom Board
 *----------------------------------------------------------------------------
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2012 Keil - An ARM Company.
 *----------------------------------------------------------------------------*/

#define RTX_TIME_1MS 1

